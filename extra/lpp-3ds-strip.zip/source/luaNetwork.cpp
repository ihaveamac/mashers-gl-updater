/*----------------------------------------------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------------------#
#------  This File is Part Of : ----------------------------------------------------------------------------------------#
#------- _  -------------------  ______   _   --------------------------------------------------------------------------#
#------ | | ------------------- (_____ \ | |  --------------------------------------------------------------------------#
#------ | | ---  _   _   ____    _____) )| |  ____  _   _   ____   ____   ----------------------------------------------#
#------ | | --- | | | | / _  |  |  ____/ | | / _  || | | | / _  ) / ___)  ----------------------------------------------#
#------ | |_____| |_| |( ( | |  | |      | |( ( | || |_| |( (/ / | |  --------------------------------------------------#
#------ |_______)\____| \_||_|  |_|      |_| \_||_| \__  | \____)|_|  --------------------------------------------------#
#------------------------------------------------- (____/  -------------------------------------------------------------#
#------------------------   ______   _   -------------------------------------------------------------------------------#
#------------------------  (_____ \ | |  -------------------------------------------------------------------------------#
#------------------------   _____) )| | _   _   ___   ------------------------------------------------------------------#
#------------------------  |  ____/ | || | | | /___)  ------------------------------------------------------------------#
#------------------------  | |      | || |_| ||___ |  ------------------------------------------------------------------#
#------------------------  |_|      |_| \____|(___/   ------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------------------#
#- Licensed under the GPL License --------------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------------------#
#- Copyright (c) Nanni <lpp.nanni@gmail.com> ---------------------------------------------------------------------------#
#- Copyright (c) Rinnegatamante <rinnegatamante@gmail.com> -------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------------------#
#- Credits : -----------------------------------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------------------#
#- Smealum for ctrulib and ftpony src ----------------------------------------------------------------------------------#
#- StapleButter for debug font -----------------------------------------------------------------------------------------#
#- Lode Vandevenne for lodepng -----------------------------------------------------------------------------------------#
#- Jean-loup Gailly and Mark Adler for zlib ----------------------------------------------------------------------------#
#- Special thanks to Aurelio for testing, bug-fixing and various help with codes and implementations -------------------#
#-----------------------------------------------------------------------------------------------------------------------*/

#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <3ds.h>
#include <fcntl.h>
#include "include/luaplayer.h"

static int connfd;
typedef struct
{
	u32 magic;
	u32 sock;
	struct sockaddr_in addrTo;
	bool serverSocket;
} Socket;

static int lua_wifistat(lua_State *L){
	int argc = lua_gettop(L);
	#ifndef SKIP_ERROR_HANDLING
		if (argc != 0) return luaL_error(L, "wrong number of arguments");
	#endif
	u32 wifiStatus;
	if (ACU_GetWifiStatus( &wifiStatus) ==  0xE0A09D2E) lua_pushboolean(L,false);
	else lua_pushboolean(L,wifiStatus);
	return 1;
}

static int lua_macaddr(lua_State *L){
	int argc = lua_gettop(L);
	#ifndef SKIP_ERROR_HANDLING
		if (argc != 0) return luaL_error(L, "wrong number of arguments");
	#endif
	u8* mac_byte = (u8*)0x1FF81060; 
	char mac_address[18];
	sprintf(mac_address,"%02X:%02X:%02X:%02X:%02X:%02X",*mac_byte,*(mac_byte+1),*(mac_byte+2),*(mac_byte+3),*(mac_byte+4),*(mac_byte+5));
	mac_address[17] = 0;
	lua_pushstring(L,mac_address);
	return 1;
}

static int lua_ipaddr(lua_State *L){
	int argc = lua_gettop(L);
	if (argc != 0) return luaL_error(L, "wrong number of arguments");
	u32 ip=(u32)gethostid();
	char ip_address[64];
	sprintf(ip_address,"%lu.%lu.%lu.%lu", ip & 0xFF, (ip>>8)&0xFF, (ip>>16)&0xFF, (ip>>24)&0xFF);
	lua_pushstring(L,ip_address);
	return 1;
}

static int lua_download(lua_State *L){
	int argc = lua_gettop(L);
	#ifndef SKIP_ERROR_HANDLING
		if (argc != 2) return luaL_error(L, "wrong number of arguments");
	#endif
	const char* url = luaL_checkstring(L,1);
	const char* file = luaL_checkstring(L,2);
	httpcContext context;
	Result ret = httpcOpenContext(&context, (char*)url , 0);
	#ifndef SKIP_ERROR_HANDLING
		if(ret==0){
	#endif
		httpcBeginRequest(&context);
		/*httpcReqStatus loading;
		httpcGetRequestState(&context, &loading);
		while (loading == 0x5){
			httpcGetRequestState(&context, &loading);
		}*/
		u32 statuscode=0;
		u32 contentsize=0;
		httpcGetResponseStatusCode(&context, &statuscode, 0);
		#ifndef SKIP_ERROR_HANDLING
			if (statuscode != 200) luaL_error(L, "download request error");
		#endif
		httpcGetDownloadSizeState(&context, NULL, &contentsize);
		u8* buf = (u8*)malloc(contentsize);
		memset(buf, 0, contentsize);
		httpcDownloadData(&context, buf, contentsize, NULL);
		Handle fileHandle;
		u32 bytesWritten;
		FS_Archive sdmcArchive=(FS_Archive){ARCHIVE_SDMC, (FS_Path){PATH_EMPTY, 1, (u8*)""}};
		FS_Path filePath=fsMakePath(PATH_ASCII, file);
		FSUSER_OpenFileDirectly( &fileHandle, sdmcArchive, filePath, FS_OPEN_CREATE|FS_OPEN_WRITE, 0x00000000);
		FSFILE_Write(fileHandle, &bytesWritten, 0, buf, contentsize,0x10001);
		FSFILE_Close(fileHandle);
		svcCloseHandle(fileHandle);
		free(buf);
	#ifndef SKIP_ERROR_HANDLING
		}else luaL_error(L, "error opening url");
	#endif
	httpcCloseContext(&context);
	return 0;
}

static int lua_downstring(lua_State *L){
	int argc = lua_gettop(L);
	#ifndef SKIP_ERROR_HANDLING
		if (argc != 1) return luaL_error(L, "wrong number of arguments");
	#endif
	const char* url = luaL_checkstring(L,1);
	httpcContext context;
	Result ret = httpcOpenContext(&context, (char*)url , 0);
	#ifndef SKIP_ERROR_HANDLING
		if(ret==0){
	#endif
		httpcBeginRequest(&context);
		/*httpcReqStatus loading;
		httpcGetRequestState(&context, &loading);
		while (loading == 0x5){
			httpcGetRequestState(&context, &loading);
		}*/
		u32 statuscode=0;
		u32 contentsize=0;
		httpcGetResponseStatusCode(&context, &statuscode, 0);
		char text[128];
		sprintf(text,"%i",statuscode);
		if (statuscode != 200) luaL_error(L, text);
		httpcGetDownloadSizeState(&context, NULL, &contentsize);
		unsigned char *buffer = (unsigned char*)malloc(contentsize+1);
		httpcDownloadData(&context, buffer, contentsize, NULL);
		buffer[contentsize] = 0;
		lua_pushlstring(L,(const char*)buffer,contentsize);
		free(buffer);
	#ifndef SKIP_ERROR_HANDLING
		}else luaL_error(L, "error opening url");
	#endif
	httpcCloseContext(&context);
	return 1;
}

static int SpaceCounter(char* string){
	int res=0;
	while (*string){
		if (string[0] == 0x20) res++;
		string++;
	}
	return res;
}

static int lua_wifilevel(lua_State *L){
	int argc = lua_gettop(L);
	#ifndef SKIP_ERROR_HANDLING
		if (argc != 0) return luaL_error(L, "wrong number of arguments");
	#endif
	u8* wifi_link = (u8*)0x1FF81066;
	lua_pushinteger(L,*wifi_link);
	return 1;
}

//Register our Network Functions
static const luaL_Reg Network_functions[] = {
  {"isWifiEnabled",			lua_wifistat},
  {"getWifiLevel",			lua_wifilevel},
  {"getMacAddress",			lua_macaddr},
  {"getIPAddress",			lua_ipaddr},
  {"downloadFile",			lua_download},
  {"requestString",			lua_downstring},
  {0, 0}
};

void luaNetwork_init(lua_State *L) {
	lua_newtable(L);
	luaL_setfuncs(L, Network_functions, 0);
	lua_setglobal(L, "Network");
}
