This is a modified lpp-3ds. Please check out https://github.com/Rinnegatamante/lpp-3ds for more information.
