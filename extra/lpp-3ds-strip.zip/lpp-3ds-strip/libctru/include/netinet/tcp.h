#pragma once

//#define SOL_TCP	???

//#define TCP_NODELAY	???
