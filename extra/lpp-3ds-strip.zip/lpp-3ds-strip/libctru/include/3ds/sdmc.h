#pragma once

#include <3ds/types.h>

Result sdmcInit(void);
Result sdmcExit(void);
